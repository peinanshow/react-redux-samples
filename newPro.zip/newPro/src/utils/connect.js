import { connectIntl } from 'redux-intl-connect';
import { connect } from 'react-redux';

export default connectIntl(connect);
