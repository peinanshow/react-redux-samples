package com.paul;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("accounts")
public class MyResource {

	/**
	 * Method handling HTTP GET requests. The returned object will be sent to the client as "text/plain" media type.
	 * 
	 * @return String that will be returned as a text/plain response.
	 */
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getIt() {
		System.out.println("aa".toString());
		return "Got it!";
	}

	/**
	 * Method handling HTTP GET requests. The returned object will be sent to the client as "text/plain" media type.
	 * 
	 * @return String that will be returned as a text/plain response.
	 */
	@POST
	@Path("login")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Token postIt(UserInfo query) {
		System.out.println(query);
		Token token = new Token();
		token.setToken("2B48AB4E437FBB1D18AC214EA9216068FDF16541823B49F75D6F72D4D7150323B4A545BF8BA58A446DA320F585C53009165D0D96D26CC81B9550870B65290FA0D40EFF940B529E62581F51A58D6CC903EFF6F48A6D528E1C4BDB0C657C437FE16F266456FB36A89CC798FC4E6D1A6097768EFDBE3E99767C2F1C329DF4B5E9EC82A24BEE571D20D5C124BED2E7CA1D253949962AA2C2B1386B19BC84DBAFE845DFA416CD5C93BBB7DF485E23B25EA7C302F8A00AD32879B787105A575E695D03D70CC72FB9870A35FEEDD76DDEE6395CDE4EBFD5994DBFD16281DE00FC8C218FBEE0730CF8CFED33044078FF36FF60FE99EF61E066C879891476A15D0F317DC16D0D898478A1AE8539DD083A875F3286537C126F38AF20B4957ABD9208F894C3B5FA2AAB0FABF83D3ED15FE1DCEC0AF6DA9CABA36BAFE3C45EF5F2C28495D0DD40463CE43ED92D68D2340CB399C96F8F");
		return token;
	}

	@GET
	@Path("check")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public CheckToken test() {
		CheckToken track = new CheckToken();
		track.setValid(true);
		return track;
	}

}
